

  * **Scripts**: The scripts;
  
  * **NetworkDataSets**: The network data sets generated from the Rocketfuel topologies;
  
  * **Simulator**: The source code of the simulator;
  
  * **OutputDataSets**: The data sets output by the simulator and from which the plots presented in Section 6 of the paper are produced;
  
  * **Plots**: The plots presented in Section 6 of the paper. 
    
## 2. Download and Installation

Our artifact is packaged in a [Docker](https://docs.docker.com) image. We show how to download and install the artifact in your local machine.
 
  1. Make sure you have Docker installed in your machine. (If you do not, then please refer to https://docs.docker.com/get-docker/.)
  
  2. Download the artifact to your local machine:
      ```
      git clone https://github.com/miferrei/rmoc-sigcomm2020-artifact.git
     ```
     and then step into the directory containing the artifact:
     ```
     cd rmoc-sigcomm2020-artifact
     ```
      
  3. Build the Docker image: 
      ```
      sudo docker build --tag rmoc-sigcomm2020-artifact:1.0 .
      ```
     This step will take about five minutes. 
  
  4. Create an interactive terminal with a local volume available in the Docker container:
      ```
      sudo docker run -v $(pwd):/root --name rmoc -it rmoc-sigcomm2020-artifact bash
      ```
      
  5. Later, to erase the artifact, first remove the Docker container and the local volume:
      ```
      sudo docker rm -v rmoc 
      ``` 
      and then the Docker image:
      ```
      sudo docker rmi rmoc-sigcomm2020-artifact:1.0 
      ``` 
      
## 3. Basic Simulator Usage

We show how to use the programs that simulate dominant-paths vectoring protocols. 

(See Section 4 of the paper for the specification of dominant-paths vectoring protocols.)

  ### 3.1. Simulation of Non-Restarting Protocols
   

  
  #### 3.1.2. Usage 
   
  The simulator is invoked with the following command:
      
      ./Simulator/Main/SimulateNonRestartingProtocol -o ORDER -n NETWORK_DATA_SET -r R 
      
  
  
## 4. Small-Scale Evaluation 

 

  1. The workflow is invoked with the following command:
  
      
      bash run-SmallScaleEvaluation.sh
      

  
  2. The plots produced can be found under directory *Plots/*, alongside those presented in Section 6 of the paper.
 

# Reproducing-Routing-on-Multiple-Optimality-Criteria
Reproducing “Routing on Multiple Optimality Criteria”

Follow steps given below to reproduce the results captured here.

Step 1:
Refer to code here: https://github.com/miferrei/rmoc-sigcomm2020-artifact

Step 2:
Update data set in following files:
run-SmallScaleEvaluation.sh
Scripts/NetworkDataSets.py
Scripts/PlotNumberDominantAttributes.py
Scripts/PlotTerminationTimes.py 

Step 3:
Remove the docker container and then the docker image

Step 4:
Build the docker container and then image

Step5:
Run the simulation: bash run-SmallScaleEvaluation.sh
