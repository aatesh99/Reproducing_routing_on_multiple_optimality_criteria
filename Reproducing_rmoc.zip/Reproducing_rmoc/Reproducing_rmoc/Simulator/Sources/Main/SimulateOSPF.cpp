#include <iomanip> 
#include <iostream>
#include <random>
#include <string>
#include <vector>
#include <time.h>

#include "RoutingTable.h"
#include "LSDatabase.h"
#include <vector>
#include "Interface.h"
#include "Neighbor.h"
using namespace Graphs;

emplate < typename S, typename Ord, typename Ext >
void RunnerSimulateNonRestartingProtocol( 
	std::string fNetwork 	,	 
	std::string fOrder  	,
	int 	    fTrails 	)
{
	std::string fileNameNetwork 	= "NetworkDataSets/" + fNetwork + ".tsv";

	std::ifstream fileNetwork   	= std::ifstream( fileNameNetwork );
	if( fileNetwork.fail()  	) 
	{	exit(1);				}

	std::cout << "\n> Test Network             = " 	<<  fNetwork   << std::endl;
	std::cout << "> Optimality Criterion     = " 	<<  fOrder     << std::endl;

	int u, v, V; 
	S attrWeight;	

	fileNetwork >> V;
	
	Graph < S > graph( V );
	while( fileNetwork >> u >> v >> attrWeight )
	{	graph.addEdge( u, v, attrWeight ); 	   }

	std::cout << std::endl;
	std::cout << "> Announcements of Destinations" 	<< std::endl;	
	std::cout << std::endl;

	std::string fileNameStableState 				 = "OutputDataSets/" + fNetwork + "/" + fOrder + "/Stable_State.tsv";

	std::ofstream fileStableState   				 = std::ofstream( fileNameStableState );
	if( fileStableState.fail()  					 )
	{	exit(1); 		   							 }

	std::string fileNameTerminationTimesAnnouncement = "OutputDataSets/" + fNetwork + "/" + fOrder + "/Termination_Times_Announcement.tsv";

	std::ofstream fileTerminationTimesAnnouncement   = std::ofstream( fileNameTerminationTimesAnnouncement );
	if( fileTerminationTimesAnnouncement.fail()  	 )
	{	exit(1); 		   						 	 }

	NonRestartingProtocol::RoutingState < S > routingState;

	int simulationsCompleted = 0;
	int simulationsTotal 	 = fTrails * graph.V;

	for( int t = 0 ; t < graph.V ; t ++ )
	{	fileTerminationTimesAnnouncement << "\t" << t;	}
	fileTerminationTimesAnnouncement 	 << "\n";

	for( int i = 0 ; i < fTrails ; i ++ )
	{
		routingState = NonRestartingProtocol::RoutingState < S >( graph.V );
		
		unsigned seed = rand();

		fileTerminationTimesAnnouncement << seed;

		std::vector < std::mt19937 > gens;
		std::mt19937 gen = std::mt19937( seed );		
		gens.clear();			
		for( int t = 0 ; t < graph.V ; t ++ )
		{	gens.push_back( std::mt19937( gen() ) ); }

		for( int t = 0 ; t < graph.V ; t ++ )
		{
			std::cout << "\r\t+ Progress = " << simulationsCompleted << " Out Of " << simulationsTotal << " Simulations Completed.";
			std::cout.flush();

			NonRestartingProtocol::DestinationAnnouncement 					  			  < S, Ord, Ext >(  graph, routingState, gens[t], t );
			double terminationTimesAnnouncement = NonRestartingProtocol::RoutingSimulator < S, Ord, Ext >(  graph, routingState, gens 	    );

			fileTerminationTimesAnnouncement << "\t" << std::setprecision(4) << terminationTimesAnnouncement;

			simulationsCompleted ++;
		}
		fileTerminationTimesAnnouncement   << "\n";
	}

	std::cout << "\r\t+ Progress = "     			  << simulationsCompleted << " Out Of "    << simulationsTotal << " Simulations Completed.";
	std::cout.flush();

	for( int t = 0 ; t < graph.V ; t ++ )
	{	fileStableState  << "\t" << t;	}
	fileStableState 	 << "\n";

	for( int s = 0 ; s < graph.V ; s ++ )
	{
		fileStableState  << s;
		
		for( int t = 0 ; t < graph.V ; t ++ )
		{
			fileStableState << "\t";

			for( auto item  = routingState.dom[s][t].begin() ; 
					  item != routingState.dom[s][t].end()   ; item ++ )
			{	
				fileStableState << " " << item->first;
			}
		}
		fileStableState << "\n";
	}

	std::cout << std::endl;
	std::cout << "\n\t+ Saving Data Set to File '"    << fileNameStableState  			       << "'." << std::endl;
	std::cout << "\n\t+ Saving Data Set to File '"    << fileNameTerminationTimesAnnouncement  << "'." << std::endl;



	std::cout << std::endl;
	std::cout << "> Failure of Links" 	   << std::endl;	
	std::cout << std::endl;

	std::string fileNameTerminationTimesFailure = "OutputDataSets/" + fNetwork + "/" + fOrder + "/Termination_Times_Failure.tsv";

	std::ofstream fileTerminationTimesFailure   = std::ofstream( fileNameTerminationTimesFailure );
	if( fileTerminationTimesFailure.fail()  )
	{	exit(1); 		   					}

	for( u = 0 ; u < graph.V ; u ++ )
	{	for( auto it  = graph.adjListOut[u].begin() ;
				  it != graph.adjListOut[u].end()	; it ++ )
		{	v = it->first;
			fileTerminationTimesFailure << "\t" << std::make_pair(u, v) ;	
		}
	}
	fileTerminationTimesFailure << "\n";

	simulationsCompleted = 0;
	simulationsTotal 	 = fTrails * graph.E ;

	for( int i = 0 ; i < fTrails ; i ++ )
	{
		unsigned seed = rand();

		fileTerminationTimesFailure << seed;

		for( u = 0 ; u < graph.V ; u ++ )
		{	for( auto it  = graph.adjListOut[u].begin() ;
				  	  it != graph.adjListOut[u].end()	; it ++ )
			{
			 	v = it->first;

				std::mt19937 gen = std::mt19937( seed );	

				std::vector < std::mt19937 > gens;
				gens.clear();				
				for( int t = 0 ; t < graph.V ; t ++ )
				{	gens.push_back( std::mt19937( gen() ) ); }

				std::cout << "\r\t+ Progress = " << simulationsCompleted << " Out Of " << simulationsTotal << " Simulations Completed.";
				std::cout.flush();

				NonRestartingProtocol::RoutingState < S > newRoutingState = routingState;

				NonRestartingProtocol::LinkFailure 						   		 		  < S, Ord, Ext >(  graph, newRoutingState, gens, u, v ); 
				double failureTerminationTimes = NonRestartingProtocol::RoutingSimulator  < S, Ord, Ext >(  graph, newRoutingState, gens 	   );

				fileTerminationTimesFailure << "\t" << std::setprecision(4) << failureTerminationTimes;
		
				simulationsCompleted ++;

				graph.activate( u, v );
			}
		}
		fileTerminationTimesFailure << "\n";
	} 

	std::cout << "\r\t+ Progress = "   			    << simulationsCompleted << " Out Of " << simulationsTotal << " Simulations Completed.";
	std::cout.flush();

	std::cout << std::endl;
	std::cout << "\n\t+ Saving Data Set to File '"  << fileNameTerminationTimesFailure    << "'." << std::endl;
	std::cout << std::endl;

	return;
}

int main( int argc, char *argv[] )
{
	std::cout << "\n--- Simulation of the OSPF Protocol" << std::endl;

	int opt;

	std::string fNetwork, fOrder;
	int fTrails = 0;

	while( ( opt = getopt( argc, argv, "n:o:r:" ) ) != -1 ) 
	{
		switch( opt )
		{	case 'n':
				fNetwork    = std::string( optarg );
				break;
			case 'o':
				fOrder 		= std::string( optarg );
				break;		
			case 'r':
				fTrails 	= atoi( optarg );
				break;
			default	:
				break;
		}
	}
}
void RoutingTable::calc()
{
	clist.clear();
	tree.clear();
	vertex root;
	root.cost = 0;
	root.id = Config::routerId;
	root.type=1;
	root.pid==0;
	tree[root.id] = root;
	vertex* newNode = &tree[root.id];
	while(true){
		//router
		if(newNode->type == 1){
			RouterLSA *lsa = LSDatabase::getRouterLSAByLinkStateId(newNode->id);
			for(vector<RouterLSALink>::iterator it = lsa->links.begin();it!=lsa->links.end();it++){
				if(it->type == 3)
					continue;
				vertex node;
				switch (it->type)
				{
				//transit network
				case 2:
					{
						if(LSDatabase::getNetworkLSAByLinkStateId(it->linkId)==NULL || tree.count(it->linkId)>0){
							continue;
						}
						node.type=2;
					}
				//router point-to-point
				case 1:
					{
						if(LSDatabase::getRouterLSAByLinkStateId(it->linkId)==NULL || tree.count(it->linkId)>0){
							continue;
						}
						node.type = 1;
					}
				default:
					break;
				}

				node.id=it->linkId;
				node.cost = newNode->cost + it->metric;
				node.pid = newNode->id;
				if(clist.count(node.id)==0 || clist[node.id].cost > node.cost){
					getNextHop(node,node.nextHop);
					clist[node.id] = node;
				}else if(clist[node.id].cost == node.cost){
					getNextHop(node,node.nextHop);
					for(set<hop>::iterator it = node.nextHop.begin();it!=node.nextHop.end();it++){
						clist[node.id].nextHop.insert(*it);
					}
				}
			}	
		}
		//transit network
		else{
			NetworkLSA *lsa = LSDatabase::getNetworkLSAByLinkStateId(newNode->id);
			vertex node;
			for(vector<uint32_t>::iterator it = lsa->routers.begin();it!=lsa->routers.end();it++){
				if(LSDatabase::getRouterLSAByLinkStateId(*it)==NULL || tree.count(*it))
					continue;
				node.cost = newNode->cost;
				node.id = *it;
				node.pid = newNode->id;
				node.type = 1;

				if(clist.count(node.id)==0 || clist[node.id].cost > node.cost){
					getNextHop(node,node.nextHop);
					clist[node.id] = node;
				}else if(clist[node.id].cost == node.cost){
					getNextHop(node,node.nextHop);
					for(set<hop>::iterator it = node.nextHop.begin();it!=node.nextHop.end();it++){
						clist[node.id].nextHop.insert(*it);
					}
				}
			}
		}

		//find out vertex in clist with shortest dist from root vertex
		uint32_t cost = 0xffffffff;
		uint32_t id = 0;
		for(map<uint32_t,vertex>::iterator it = clist.begin();it!=clist.end();it++){
			if(it->second.cost<=cost){
				if(id!=0 && clist[id].type == 2 && it->second.type==1 && cost == it->second.cost)
					continue;

				cost = it->second.cost;
				id = it->first;
			}
		}
		if(id!=0){
			tree[id] = clist[id];
			clist.erase(id);
			newNode = &tree[id];
		}
	}
}

void RoutingTable::getNextHop( vertex& node,set<hop>& nextHop )
{
	bool intervene = false;
	uint32_t ptr = node.pid;
	while((ptr = tree[ptr].pid)!=0){
		if(tree[ptr].type==1){
			intervene = true;
			break;
		}
	}
	if(intervene){
		nextHop = clist[node.pid].nextHop;
	}
	else{
		hop hopnode;
		//parent is the calc router
		if(tree[node.pid].type==1){
			for(vector<Interface*>::iterator it = Config::inters.begin();it!=Config::inters.end();it++){
				if(node.type==1){
					for(list<Neighbor*>::iterator nit = (*it)->nbrList.begin();nit!=(*it)->nbrList.end();nit++)
					{
						if((*nit)->id == node.id){
							hopnode.inter = *it;
							
						}
					}
				}
				//transit network
				else{
					if((*it)->getNbrByIp((*it)->dr)->id == node.id){
						hopnode.inter = *it;
						hopnode.ip = 0;
					}
				}
			}
		}
		//parent is transit network
		else{
			RouterLSA* lsa = LSDatabase::getRouterLSAByLinkStateId(node.id);
			for(vector<RouterLSALink>::iterator it = lsa->links.begin();it!=lsa->links.end();it++){
				if(it->linkId == tree[node.pid].id){
					hopnode.ip = it->linkData;
					for(vector<Interface*>::iterator iit = Config::inters.begin();iit!=Config::inters.end();iit++){
						if((*iit)->getNbrByIp(hopnode.ip)!=NULL){
							hopnode.inter = *iit;
							break;
						}	
					}
					break;
				}
			}
		}
		nextHop.insert(hopnode);
	}
}
