# Reproducing-Routing-on-Multiple-Optimality-Criteria
Reproducing “Routing on Multiple Optimality Criteria”

Follow steps given below to reproduce the results captured here.

Step 1:
Refer to code here: https://github.com/miferrei/rmoc-sigcomm2020-artifact

Step 2:
Update data set in following files:
run-SmallScaleEvaluation.sh
Scripts/NetworkDataSets.py
Scripts/PlotNumberDominantAttributes.py
Scripts/PlotTerminationTimes.py 

Step 3:
Remove the docker container and then the docker image

Step 4:
Build the docker container and then image

Step5:
Run the simulation: bash run-SmallScaleEvaluation.sh
