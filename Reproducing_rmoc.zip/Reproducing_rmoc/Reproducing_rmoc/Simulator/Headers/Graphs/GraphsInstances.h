namespace Graphs
{
	template struct Graph < std::pair  < int, int > >;
	template struct Graph < std::tuple < int, int, int > >;
}