# Python code to
# change last int to random int
import random

# Give input filename here
file1 = open('test.txt', 'r')
Lines = file1.readlines()
  
# Give result file name
filew = open('myfile.txt', 'w')

count = 0
# Strips the newline character
for line in Lines:
    count += 1
    print("Line{}: {}".format(count, line.strip()))
    text = line.strip() #strip() gets rid of new line character or spaces
    
    size = len(text)   # text length
    replacement = random.randint(1, 50) # replace with random int in given range

    text = text.replace(text[size - 1:], str(replacement))

    print("String after: ", text)

    # write it to a new file
    # writing to file
    filew.writelines(text + "\n")

file1.close()
filew.close()
