# Python code to
# select given number of random lines
import random

# Give input filename here
file1 = open('test.txt', 'r')
Lines = file1.readlines()
  
# Give result file name
filew = open('myfile.txt', 'w')

# Give the number of line you want to select
N = 80 # we will select 5 lines randomly

selected_lines = 0
count = 0
# Strips the newline character
for line in Lines:
    count += 1
    print("Line{}: {}".format(count, line.strip()))
    text = line.strip()

    select_or_not = random.randint(0,1) # will be either 0 or 1
    
    # randomly select n lines and write it to a new file
    if select_or_not:
        selected_lines = selected_lines+1
        # writing to file
        filew.writelines(text + "\n")
        print("Selected line: ", text)
    if (selected_lines >=N): break

file1.close()
filew.close()
